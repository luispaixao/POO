/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingresoo;

import ingresoo.modelo.Compra;
import ingresoo.modelo.Ingresso;
import ingresoo.modelo.Local;
import ingresoo.modelo.Show;
import ingresoo.modelo.TiposDeIngresso;
import ingresoo.modelo.Turne;
import java.util.*;

/**
 *
 * @author egouvea
 */
public class IngresOO {
    static List<Turne> turnes = new ArrayList<>();
    static List<Compra> carrinho = new ArrayList<>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Opcao = 1, show = 0, compra = 0, quantidade = 0;
        boolean numeroCartao;

        Scanner teclado = new Scanner(System.in);
        inicializa();
        while (Opcao != 0) {
            mostraMenu();
            Opcao = teclado.nextInt();
            if (Opcao != 0){
                show = mostraShows(Opcao-1);
                compra = mostraIngressos(Opcao-1, show-1);
                quantidade = quantidadeIngressos();
                carrinho.add(new Compra(quantidade, turnes.get(Opcao-1).getShows().get(show-1).getTiposIngressos().get(compra-1)));
                if(!continuarComprando()){
                    if(mostrarCarrinho()){
                        if(finalizarCompra()){
                            numeroCartao();
                        }
                    }else{
                        carrinho = new ArrayList<>();
                    }
                }
            }
        }

        teclado.close();
    }
    
    private static void mostraMenu() {
        int item = 1;
        System.out.println("");
        for (Turne turne : turnes) {
            System.out.println(item + " - " + turne.getTurne());
            item++;
        }	
        System.out.println("0 - Sair");
    }
    
    private static int mostraIngressos(int Opcao, int show) {
        int item = 1;
        Scanner teclado = new Scanner(System.in);
        Turne t = turnes.get(Opcao);
        Show s = t.getShows().get(show);
        for (Ingresso i : s.getTiposIngressos()) {
            System.out.print(item + " - " + i.getTipo() + " - " + i.getPreco() + "\n");
            item++;
        }
        System.out.print("Selecione: ");
        return teclado.nextInt();
    }
    
    private static int quantidadeIngressos(){
        Scanner teclado = new Scanner(System.in);
        System.out.print("Selecione a quantidade de ingressos: ");
        return teclado.nextInt();
    }
    
    private static int mostraShows(int n) {
        int num=1;
        Scanner teclado = new Scanner(System.in);
        Turne t = turnes.get(n);
        System.out.println("");
        System.out.println(t.getNomeDaBanda() + " - " + t.getTurne());
        for (Show show : t.getShows()){
            System.out.println(num + " - " + show.getLocal().getNome() + " - " + show.getData());
            num++;
        }
        
        System.out.print("Selecione: ");
        return teclado.nextInt();
    }
    
    private static boolean numeroCartao() {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite o numero do cartao: ");
        String numeroCartao = teclado.nextLine();
        
        System.out.print("Nome Completo: ");
        String nomeCartao = teclado.nextLine();

        System.out.print("Data de validade: ");
        String dataValidade = teclado.nextLine();

        System.out.print("Código de segurança: ");
        String codigoSeguranca = teclado.nextLine();

        if(cartaoValido(numeroCartao, nomeCartao, dataValidade, codigoSeguranca)){
            System.out.println("Compra finalizada com sucesso!");
            return true;
        }else{
            System.out.println("Compra não foi finalizada!");
            return false;
        }
    }
    
    static public void inicializa(){
        Ingresso pista = new Ingresso(30, TiposDeIngresso.TiposDeIngressos.Pista);
        Ingresso cadeiraLateral = new Ingresso(30, TiposDeIngresso.TiposDeIngressos.Cadeira_Lateral);
        Ingresso cadeiraSuperior = new Ingresso(30, TiposDeIngresso.TiposDeIngressos.Cadeira_Superior);
        Ingresso camarote = new Ingresso(30, TiposDeIngresso.TiposDeIngressos.Camarote);

        List<Ingresso> ingressos = new ArrayList<>();
        ingressos.add(pista);
        ingressos.add(cadeiraLateral);
        ingressos.add(cadeiraSuperior);
        ingressos.add(camarote);
                
        Local sp = new Local("São Paulo");
        Local bh = new Local("Belo Horizonte");
        Local rj = new Local("Rio de Janeiro");
        
        Turne t1 = new Turne();
        t1.setTurne("The Trooper");
        t1.setNomeDaBanda("Iron Maiden");
        Show s1 = new Show(rj, "20181010", ingressos);
        t1.cadastrarItem(s1);
        Show s1s2= new Show(sp, "20181012", ingressos);
        t1.cadastrarItem(s1s2);
        turnes.add(t1);
        
        Turne t2 = new Turne();
        t2.setTurne("Parachutes");
        t2.setNomeDaBanda("Coldplay");
        Show s2 = new Show(sp, "20181212", ingressos);
        t2.cadastrarItem(s2);
        turnes.add(t2);
        
        Turne t3 = new Turne();
        t3.setTurne("360");
        t3.setNomeDaBanda("U2");
        Show s3 = new Show(rj, "20181210", ingressos);
        t3.cadastrarItem(s3);
        turnes.add(t3);
        
        Turne t4 = new Turne();
        t4.setTurne("A Bigger Bang");
        t4.setNomeDaBanda("Rolling Stones");
        Show s4 = new Show(bh,"20180609", ingressos);
        t4.cadastrarItem(s4);
        turnes.add(t4);
    }

    private static boolean cartaoValido(String numeroCartao, String nomeCartao, String dataValidade, String codigoSeguranca) {
        String blocosCartao[] = numeroCartao.split(" ");
        if(blocosCartao.length == 4){
            return true;
        }
        return false;
    }

    private static boolean finalizarCompra() {
        Scanner teclado = new Scanner(System.in);
        int resposta = 0;
        while(resposta <1 || resposta > 2){
            System.out.println("Deseja finalizar compra?");
            System.out.println("1 - Sim");
            System.out.println("2 - Não");
            resposta = teclado.nextInt();
        }
        if(resposta == 1){
            return true;
        }
        return false;
    }
    
    private static boolean mostrarCarrinho(){
        Scanner teclado = new Scanner(System.in);
        int num = 1;
        double total=0;
        int resposta = 0;
        
        System.out.println("\nDados do carrinho: ");
        for(Compra compra : carrinho){
            System.out.println(num + " - R$ " + compra.getIngresso().getPreco() + " " + compra.getQuantidade() + " " + compra.calculaTotal());
            num++;
            total += compra.calculaTotal();
        }
        System.out.println("Total da compra: R$ " + total);
        while(resposta <1 || resposta > 2){
            System.out.println("\nDeseja confirmar aquisição?");
            System.out.println("1 - Sim");
            System.out.println("2 - Não");
            resposta = teclado.nextInt();
        }
        if(resposta == 1){
            return true;
        }
        return false;
    }

    private static boolean continuarComprando() {
        int resposta = 0;
        Scanner teclado = new Scanner(System.in);
        while(resposta <1 || resposta > 2){
            System.out.println("Deseja continuar comprando?");
            System.out.println("1 - Sim");
            System.out.println("2 - Não");
            resposta = teclado.nextInt();
        }
        if(resposta == 1){
            return true;
        }
        return false;
    }
}
