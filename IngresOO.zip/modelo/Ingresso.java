/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingresoo.modelo;

import ingresoo.modelo.TiposDeIngresso.TiposDeIngressos;

/**
 *
 * @author egouvea
 */
public class Ingresso {
    private double preco;
    private int tipoIngresso;
    
    public Ingresso(double preco, TiposDeIngressos tipoIngresso){
        this.preco = preco;
        this.tipoIngresso = tipoIngresso.getNumeroTipo();
    }
   
    public String getTipo() {
        return TiposDeIngresso.TiposDeIngressos.values()[tipoIngresso-1].toString();
    }

    public void setTipo(int tipo) {
        this.tipoIngresso = tipo-1;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preço) {
        this.preco = preço;
    }
}
