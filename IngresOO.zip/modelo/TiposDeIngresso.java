/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingresoo.modelo;

/**
 *
 * @author egouvea
 */
public class TiposDeIngresso {
    public enum TiposDeIngressos {
	Pista(1),
	Cadeira_Lateral(2),
	Cadeira_Superior(3),
	Camarote(4);
        
        private final int numeroTipoIngresso;

        private TiposDeIngressos(int valor) {
            numeroTipoIngresso = valor;
        }
        
        public int getNumeroTipo(){
            return this.numeroTipoIngresso;
        }
    }
}
