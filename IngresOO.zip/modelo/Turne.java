/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingresoo.modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author egouvea
 */
public class Turne {
    String Nome;
    String NomeDaBanda;
    List<Show> Shows = new ArrayList<>();

    public String getNomeDaBanda() {
        return NomeDaBanda;
    }

    public void setNomeDaBanda(String nomeDaBanda) {
        NomeDaBanda = nomeDaBanda;
    }

    public String getTurne() {
        return Nome;
    }

    public void setTurne(String turne) {
        Nome = turne;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public List<Show> getShows() {
        return Shows;
    }

    public void setShows(List<Show> Shows) {
        this.Shows = Shows;
    }
    
    public void cadastrarItem(Show show){
        this.Shows.add(show);
    }
}
