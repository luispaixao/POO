/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingresoo.modelo;

import java.util.List;

/**
 *
 * @author egouvea
 */
public class Compra {
    private int quantidade;
    private Ingresso ingresso;
    
    public Compra(int quantidade, Ingresso ingresso){
        this.quantidade = quantidade;
        this.ingresso = ingresso;
    }
    
    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Ingresso getIngresso() {
        return ingresso;
    }

    public void setIngresso(Ingresso ingresso) {
        this.ingresso = ingresso;
    }
    
    public double calculaTotal(){
        return ingresso.getPreco()*quantidade;
    }
}