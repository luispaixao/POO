/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingresoo.modelo;

import java.util.List;

/**
 *
 * @author egouvea
 */
public class Show {
    private Local local;
    private String data;
    private List<Ingresso> tiposIngressos;

    public Show (Local local, String data, List<Ingresso> tiposIngressos) {
        this.local = local;
        this.data = data;
        this.tiposIngressos = tiposIngressos;
    }

    public Local getLocal() {
        return local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }

    public String getData() {
        return data.substring(6,8)+"/"+data.substring(4,6)+"/"+data.substring(0,4);
    }

    public void setData(String data) {
        this.data = data;
    }
    
    public List<Ingresso> getTiposIngressos() {
        return tiposIngressos;
    }

    public void setTiposIngresso(List<Ingresso> tiposIngressos) {
        this.tiposIngressos = tiposIngressos;
    }
}
